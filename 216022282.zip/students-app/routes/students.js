var express = require('express');
var router = express.Router();

//try
const studentList = [
  {
    id: '001',
    name: 'Bliss Corblah',
    date_of_birth: '1992-11-20',
    programme: 'BSCIT',
    level: '400'
  },
  {
    id: '002',
    name: 'Enoch aworo Frimpong',
    date_of_birth: '1998-07-19',
    programme: 'BSCCS',
    level: '300'
  },
  {
    id: '003',
    name: 'Favor Omenix',
    date_of_birth: '1993-11-08',
    programme: 'BSCMIS',
    level: '200'
  }
];


/* GET students listing. */
router.get('/', function(req, res,) {
  res.render('students',{title: 'Students', studentList});
});




module.exports = router;
