var express = require('express');
var router = express.Router();

//try
var list = [
  {
    name: 'Bill_Gates',
    DOB: '1994-03-19',
    programme: 'BSc CS',
    level: '400',
    image: "/images/bill.jpg"
  },
  {
    name: 'Fidel_Castro',
    DOB: '1992-07-28',
    programme: 'BSc CS',
    level: '300',
    image: "/images/Castro.jpg"
  },
  {
    name: 'Hard_man',
    DOB: '1990-04-14',
    programme: 'BSc ICT',
    level: '400',
    image: "/images/hard_man.jpg"
  },
  {
    name: 'Malcom_X',
    DOB: '1997-09-18',
    programme: 'BSc ICT',
    level: '300',
    image: "/images/Malcom.jpg"
  },
  {
    name: 'Jerry_Rwallings',
    DOB: '1995-11-20',
    programme: 'BSc ICT',
    level: '200',
    image: "/images/jerry.jpg"
  }
 
];


/* GET students listing. */
router.get('/', function(req, res,) {
  res.render('students',{title: 'Students', list});
});
// GET student details
router.get('/:id', (req, res,) => {
  let index = req.params.id
  res.render('details', {title: "student's details", student: list[index]  });
 });
 
module.exports = router;
